# Cara build APK hanya dengan HP (melalui GitHub Actions)

Workflow `.github/workflows/build-apk.yml` dapat membangun APK di server GitHub, jadi kamu tidak perlu memasang Android Studio atau Android SDK di HP.

## Langkah
1. Di browser HP, masuk ke GitHub dan buat repository baru bernama `LuxFinanceApp`.
2. Unggah isi folder proyek ini ke root repository (jangan unggah folder pembungkus `LuxFinanceApp` sebagai satu folder di dalam root). Pastikan `settings.gradle.kts`, `build.gradle.kts`, folder `app/`, dan `.github/workflows/build-apk.yml` terlihat di root.
3. Buka tab **Actions** pada repository dan aktifkan Actions jika diminta.
4. Pilih workflow **Build Lux Finance APK** → **Run workflow** → **Run workflow**.
5. Tunggu sampai selesai hijau. Buka run yang selesai, gulir ke bagian **Artifacts**, lalu unduh `LuxFinance-debug-APK`.
6. Ekstrak ZIP artifact di HP, lalu ketuk `app-debug.apk` untuk memasang. Jika diminta, izinkan pemasangan dari sumber tersebut di pengaturan Android.

## Catatan
- Repository harus berisi kode sumber; jangan hanya mengunggah file ZIP proyek kecuali workflow diubah untuk mengekstraknya.
- GitHub mungkin meminta verifikasi akun atau mengaktifkan Actions.
- APK debug ini untuk uji coba. Belum ditandatangani sebagai rilis Play Store.
- Build dapat gagal jika ada masalah kode atau dependensi; periksa log pada run Actions.
