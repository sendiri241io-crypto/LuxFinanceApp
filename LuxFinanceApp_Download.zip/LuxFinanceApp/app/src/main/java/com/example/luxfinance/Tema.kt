package com.example.luxfinance

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// ============================================================
// PALET WARNA "DARK LUXURY"
// Dasar hampir hitam, aksen emas, hijau/merah dibuat lembut
// supaya tidak "berteriak" di atas latar gelap.
// ============================================================
object LuxColors {
    val Background = Color(0xFF0A0A0F)
    val BackgroundTop = Color(0xFF17130B)   // sedikit kecokelatan, memberi kesan hangat
    val Surface = Color(0xFF14141B)
    val SurfaceHigh = Color(0xFF1D1D27)

    val Gold = Color(0xFFD4AF37)
    val GoldLight = Color(0xFFF3E2A9)
    val GoldDark = Color(0xFF8C6D1F)

    val Income = Color(0xFF4ADE9A)
    val Expense = Color(0xFFFF6B7A)

    val TextPrimary = Color(0xFFF5F1E8)     // putih gading, lebih elegan dari putih murni
    val TextSecondary = Color(0xFF9C9AA6)
}

/** Gradien emas untuk tombol, aksen, dan ikon. */
val GoldGradient: Brush = Brush.linearGradient(
    colors = listOf(LuxColors.GoldLight, LuxColors.Gold, LuxColors.GoldDark)
)

/** Latar layar: gelap kecokelatan di atas, hitam pekat di bawah. */
val BackgroundGradient: Brush = Brush.verticalGradient(
    colors = listOf(LuxColors.BackgroundTop, LuxColors.Background)
)

private val LuxColorScheme = darkColorScheme(
    primary = LuxColors.Gold,
    onPrimary = LuxColors.Background,
    secondary = LuxColors.GoldLight,
    background = LuxColors.Background,
    onBackground = LuxColors.TextPrimary,
    surface = LuxColors.Surface,
    onSurface = LuxColors.TextPrimary,
    surfaceVariant = LuxColors.SurfaceHigh,
    onSurfaceVariant = LuxColors.TextSecondary
)

@Composable
fun LuxTheme(content: @Composable () -> Unit) {
    // Sengaja dark-only: tema luxury ini tidak punya versi terang.
    MaterialTheme(colorScheme = LuxColorScheme, content = content)
}
