package com.example.luxfinance

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

// ============================================================
// ENTRY POINT
// ============================================================
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Edge-to-edge dengan ikon status bar terang (cocok untuk latar gelap)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT)
        )
        setContent {
            LuxTheme { DashboardScreen() }
        }
    }
}

// ============================================================
// LAYAR UTAMA
// ============================================================
@Composable
fun DashboardScreen(viewModel: KeuanganViewModel = viewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var tampilkanForm by rememberSaveable { mutableStateOf(false) }
    var transaksiUntukDihapus by remember { mutableStateOf<Transaksi?>(null) }

    // Id item yang sudah pernah dianimasikan. Sengaja bukan State:
    // mengubahnya tidak perlu memicu recomposition.
    val sudahTampil = remember { mutableSetOf<String>() }

    Box(Modifier.fillMaxSize().background(BackgroundGradient)) {
        Scaffold(
            containerColor = Color.Transparent,
            floatingActionButton = { TombolTambahMewah(onClick = { tampilkanForm = true }) }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(
                    start = 20.dp,
                    end = 20.dp,
                    top = padding.calculateTopPadding() + 16.dp,
                    bottom = padding.calculateBottomPadding() + 100.dp // ruang agar tombol tidak menutupi item terakhir
                ),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item { HeaderDashboard() }

                item {
                    Spacer(Modifier.height(4.dp))
                    AnimasiMuncul(kunci = "kartu_saldo", sudahTampil = sudahTampil) {
                        KartuSaldo(state.ringkasan)
                    }
                }

                item {
                    Spacer(Modifier.height(8.dp))
                    BarisFilter(
                        state = state,
                        onTipe = viewModel::setFilterTipe,
                        onKategori = viewModel::setFilterKategori
                    )
                }

                item {
                    Text(
                        text = "Riwayat Transaksi",
                        color = LuxColors.TextPrimary,
                        style = MaterialTheme.typography.titleMedium,
                        fontFamily = FontFamily.Serif,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                if (state.daftar.isEmpty()) {
                    item {
                        Text(
                            text = "Belum ada transaksi untuk filter ini.",
                            color = LuxColors.TextSecondary,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }

                // `key` wajib: dengan key yang stabil, Compose tahu item mana yang baru,
                // dan animateItem() bisa menganimasikan tambah/hapus/urutan.
                itemsIndexed(items = state.daftar, key = { _, t -> t.id }) { index, transaksi ->
                    Box(Modifier.animateItem()) {
                        AnimasiMuncul(
                            kunci = transaksi.id,
                            sudahTampil = sudahTampil,
                            // Cascade hanya untuk 6 item pertama; item hasil scroll langsung muncul
                            delayMs = if (index < 6) index * 70L else 0L
                        ) {
                            ItemTransaksi(transaksi, onLongClick = { transaksiUntukDihapus = transaksi })
                        }
                    }
                }
            }
        }
    }

    transaksiUntukDihapus?.let { transaksi ->
        AlertDialog(
            onDismissRequest = { transaksiUntukDihapus = null },
            containerColor = LuxColors.SurfaceHigh,
            title = { Text("Hapus transaksi?", color = LuxColors.TextPrimary) },
            text = { Text("\"${transaksi.judul}\" akan dihapus dari riwayat.", color = LuxColors.TextSecondary) },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.hapus(transaksi.id)
                    transaksiUntukDihapus = null
                }) { Text("Hapus", color = LuxColors.Expense) }
            },
            dismissButton = {
                TextButton(onClick = { transaksiUntukDihapus = null }) {
                    Text("Batal", color = LuxColors.Gold)
                }
            }
        )
    }

    if (tampilkanForm) {
        FormTambahDialog(
            onDismiss = { tampilkanForm = false },
            onSimpan = { transaksi ->
                viewModel.tambah(transaksi)
                tampilkanForm = false
            }
        )
    }
}

// ============================================================
// BAGIAN-BAGIAN LAYAR
// ============================================================
@Composable
private fun HeaderDashboard() {
    Column {
        Text(
            text = "Selamat datang kembali",
            color = LuxColors.TextSecondary,
            style = MaterialTheme.typography.labelLarge
        )
        Text(
            text = "Ringkasan Keuangan",
            color = LuxColors.TextPrimary,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.SemiBold,
            fontSize = 28.sp
        )
    }
}

/** Kartu utama: saldo besar + dua angka kecil (pemasukan/pengeluaran), semuanya count-up. */
@Composable
private fun KartuSaldo(ringkasan: RingkasanKeuangan) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(24.dp)) {
            Text(
                text = "TOTAL SALDO",
                color = LuxColors.GoldLight,
                style = MaterialTheme.typography.labelMedium,
                letterSpacing = 2.sp
            )
            Spacer(Modifier.height(8.dp))
            AnimatedRupiah(
                target = ringkasan.sisaSaldo,
                style = TextStyle(
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 38.sp
                )
            )
            Spacer(Modifier.height(24.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MiniStat("↓ Pemasukan", ringkasan.totalPemasukan, LuxColors.Income, Modifier.weight(1f))
                MiniStat("↑ Pengeluaran", ringkasan.totalPengeluaran, LuxColors.Expense, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun MiniStat(label: String, nilai: Long, warna: Color, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.05f))
            .padding(12.dp)
    ) {
        Text(text = label, color = warna, style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(4.dp))
        AnimatedRupiah(
            target = nilai,
            style = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
            durasiMs = 1300
        )
    }
}

/** Dua baris chip: filter tipe, lalu filter kategori (bisa digeser ke samping). */
@Composable
private fun BarisFilter(
    state: KeuanganUiState,
    onTipe: (TipeTransaksi?) -> Unit,
    onKategori: (String?) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ChipFilter("Semua", aktif = state.filterTipe == null, onClick = { onTipe(null) })
            TipeTransaksi.entries.forEach { tipe ->
                ChipFilter(tipe.label, aktif = state.filterTipe == tipe, onClick = { onTipe(tipe) })
            }
        }
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ChipFilter("Semua Kategori", aktif = state.filterKategori == null, onClick = { onKategori(null) })
            state.kategoriTersedia.forEach { kategori ->
                ChipFilter(kategori, aktif = state.filterKategori == kategori, onClick = { onKategori(kategori) })
            }
        }
    }
}

/** Satu baris riwayat. Hijau + untuk pemasukan, merah - untuk pengeluaran. */
@Composable
private fun ItemTransaksi(transaksi: Transaksi, onLongClick: () -> Unit, modifier: Modifier = Modifier) {
    val pemasukan = transaksi.tipe == TipeTransaksi.PEMASUKAN
    val warna = if (pemasukan) LuxColors.Income else LuxColors.Expense
    val tanda = if (pemasukan) "+" else "-"
    val bentuk = RoundedCornerShape(20.dp)

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(bentuk)
            .background(LuxColors.Surface)
            .border(1.dp, Color.White.copy(alpha = 0.06f), bentuk)
            .combinedClickable(onClick = {}, onLongClick = onLongClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(warna.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = if (pemasukan) "↓" else "↑",
                color = warna,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = transaksi.judul,
                color = LuxColors.TextPrimary,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
                maxLines = 1
            )
            Text(
                text = "${transaksi.kategori} • ${transaksi.tanggal.formatTanggal()}",
                color = LuxColors.TextSecondary,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 1
            )
        }
        Spacer(Modifier.width(8.dp))
        Text(
            text = "$tanda ${formatRupiah(transaksi.nominal)}",
            color = warna,
            fontWeight = FontWeight.SemiBold,
            style = MaterialTheme.typography.bodyMedium,
            maxLines = 1
        )
    }
}

// ============================================================
// FORM TAMBAH TRANSAKSI (dialog sederhana)
// ============================================================
@Composable
private fun FormTambahDialog(
    onDismiss: () -> Unit,
    onSimpan: (Transaksi) -> Unit
) {
    var judul by remember { mutableStateOf("") }
    var nominalTeks by remember { mutableStateOf("") }
    var tipe by remember { mutableStateOf(TipeTransaksi.PENGELUARAN) }
    var kategori by remember { mutableStateOf(Kategori.untuk(TipeTransaksi.PENGELUARAN).first()) }

    val warnaField = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = LuxColors.Gold,
        unfocusedBorderColor = Color.White.copy(alpha = 0.15f),
        focusedLabelColor = LuxColors.Gold,
        unfocusedLabelColor = LuxColors.TextSecondary,
        cursorColor = LuxColors.Gold,
        focusedTextColor = LuxColors.TextPrimary,
        unfocusedTextColor = LuxColors.TextPrimary
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = LuxColors.SurfaceHigh,
        shape = RoundedCornerShape(24.dp),
        title = {
            Text("Transaksi Baru", color = LuxColors.TextPrimary, fontFamily = FontFamily.Serif)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TipeTransaksi.entries.forEach { pilihan ->
                        ChipFilter(
                            label = pilihan.label,
                            aktif = tipe == pilihan,
                            onClick = {
                                tipe = pilihan
                                kategori = Kategori.untuk(pilihan).first() // kategori ikut tipe
                            }
                        )
                    }
                }
                OutlinedTextField(
                    value = judul,
                    onValueChange = { judul = it },
                    label = { Text("Judul") },
                    singleLine = true,
                    colors = warnaField
                )
                OutlinedTextField(
                    value = nominalTeks,
                    // Hanya angka, maksimal 12 digit (menghindari overflow Long)
                    onValueChange = { input -> nominalTeks = input.filter { it.isDigit() }.take(12) },
                    label = { Text("Nominal (Rp)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    colors = warnaField
                )
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Kategori.untuk(tipe).forEach { pilihan ->
                        ChipFilter(pilihan, aktif = kategori == pilihan, onClick = { kategori = pilihan })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val nominal = nominalTeks.toLongOrNull()
                // Validasi sederhana: judul terisi dan nominal > 0
                if (judul.isNotBlank() && nominal != null && nominal > 0) {
                    onSimpan(
                        Transaksi(
                            judul = judul.trim(),
                            nominal = nominal,
                            tipe = tipe,
                            kategori = kategori
                        )
                    )
                }
            }) {
                Text("Simpan", color = LuxColors.Gold, fontWeight = FontWeight.SemiBold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal", color = LuxColors.TextSecondary)
            }
        }
    )
}
