package com.example.luxfinance

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.roundToLong

// ============================================================
// 1. GLASS CARD
// Compose tidak punya "backdrop blur" bawaan, jadi efek kaca
// disimulasikan: gradien semi-gelap + border gradien tipis
// + cahaya emas di pojok + kilau yang menyapu pelan.
// ============================================================
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 28.dp,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)

    // Posisi kilau bergerak -0.5 -> 1.5 (kali lebar kartu), diulang terus.
    val transisi = rememberInfiniteTransition(label = "kilau")
    val geser by transisi.animateFloat(
        initialValue = -0.5f,
        targetValue = 1.5f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 5200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "geserKilau"
    )

    Box(
        modifier = modifier
            .clip(shape)
            // Lapisan dasar: gelap, dengan semburat emas di sudut kiri atas
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF2A2415), Color(0xFF16161D), Color(0xFF0F0F14))
                )
            )
            // Tepi kaca: terang di sudut atas, nyaris hilang di tengah
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    listOf(
                        LuxColors.Gold.copy(alpha = 0.70f),
                        Color.White.copy(alpha = 0.08f),
                        LuxColors.Gold.copy(alpha = 0.35f)
                    )
                ),
                shape = shape
            )
            // Dua efek gambar di bawah isi kartu. `geser` dibaca di fase DRAW,
            // jadi animasi tidak memicu recomposition sama sekali.
            .drawBehind {
                val pusat = Offset(size.width * 0.92f, size.height * 0.02f)
                val radius = size.width * 0.55f
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(LuxColors.Gold.copy(alpha = 0.38f), Color.Transparent),
                        center = pusat,
                        radius = radius
                    ),
                    radius = radius,
                    center = pusat
                )
                val x = size.width * geser
                drawRect(
                    brush = Brush.linearGradient(
                        colors = listOf(Color.Transparent, Color.White.copy(alpha = 0.07f), Color.Transparent),
                        start = Offset(x, 0f),
                        end = Offset(x + size.width * 0.35f, size.height * 0.6f)
                    )
                )
            },
        content = content
    )
}

// ============================================================
// 2. COUNT-UP ANGKA RUPIAH
// Dipakai untuk saldo, total pemasukan, dan total pengeluaran.
// - Saat pertama tampil: hitung naik dari 0.
// - Saat nilai berubah (tambah transaksi): geser mulus dari angka lama ke baru.
// Yang dianimasikan adalah fraksi 0..1, bukan nilai rupiahnya, karena Float
// hanya akurat sampai sekitar 16 juta; dengan fraksi, hasil akhir selalu persis.
// ============================================================
@Composable
fun AnimatedRupiah(
    target: Long,
    modifier: Modifier = Modifier,
    style: TextStyle = MaterialTheme.typography.headlineMedium,
    color: Color = LuxColors.TextPrimary,
    durasiMs: Int = 1500
) {
    val progress = remember { Animatable(0f) }
    var awal by remember { mutableLongStateOf(0L) }
    var akhir by remember { mutableLongStateOf(0L) }

    // Jalan ulang setiap `target` berubah; animasi lama otomatis dibatalkan.
    LaunchedEffect(target) {
        // Titik mulai = angka yang sedang tampil sekarang (supaya tidak "loncat")
        awal = nilaiSaatIni(awal, akhir, progress.value)
        akhir = target
        progress.snapTo(0f)
        progress.animateTo(1f, tween(durasiMs, easing = FastOutSlowInEasing))
    }

    Text(
        text = formatRupiah(nilaiSaatIni(awal, akhir, progress.value)),
        modifier = modifier,
        style = style,
        color = color,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
    )
}

private fun nilaiSaatIni(awal: Long, akhir: Long, fraksi: Float): Long =
    awal + ((akhir - awal) * fraksi.toDouble()).roundToLong()

// ============================================================
// 3. ANIMASI MUNCUL (FADE + SLIDE + SCALE KECIL)
// Dibungkus di sekeliling tiap item LazyColumn. Item dianimasikan saat
// pertama kali masuk layar; item yang pernah tampil tidak diulang lagi
// ketika di-scroll balik (dicatat di `sudahTampil`).
// ============================================================
@Composable
fun AnimasiMuncul(
    kunci: String,
    sudahTampil: MutableSet<String>,
    modifier: Modifier = Modifier,
    delayMs: Long = 0L,
    content: @Composable () -> Unit
) {
    val perluAnimasi = remember { kunci !in sudahTampil }
    val progress = remember { Animatable(if (perluAnimasi) 0f else 1f) }

    LaunchedEffect(Unit) {
        sudahTampil.add(kunci)
        if (perluAnimasi) {
            delay(delayMs) // efek berurutan (stagger) untuk item pertama
            progress.animateTo(1f, tween(durationMillis = 450, easing = FastOutSlowInEasing))
        }
    }

    Box(
        modifier = modifier.graphicsLayer {
            // Dibaca di fase layer/draw: sangat ringan, tanpa recomposition per frame
            val p = progress.value
            alpha = p
            translationY = (1f - p) * 48.dp.toPx()
            val skala = 0.96f + 0.04f * p
            scaleX = skala
            scaleY = skala
        }
    ) { content() }
}

// ============================================================
// 4. TOMBOL TAMBAH DENGAN ANIMASI MIKRO
// - Menekan: mengecil + ikon berputar 90 derajat (spring, sedikit memantul)
// - Dilepas: kembali dengan pantulan halus
// - Ripple bawaan + getaran haptic + glow emas
// ============================================================
@Composable
fun TombolTambahMewah(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interaksi = remember { MutableInteractionSource() }
    val ditekan by interaksi.collectIsPressedAsState()
    val haptic = LocalHapticFeedback.current

    val skala by animateFloatAsState(
        targetValue = if (ditekan) 0.88f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "skalaTombol"
    )
    val rotasi by animateFloatAsState(
        targetValue = if (ditekan) 90f else 0f,
        animationSpec = tween(250, easing = FastOutSlowInEasing),
        label = "rotasiIkon"
    )

    Box(
        modifier = modifier
            .size(64.dp)
            .graphicsLayer {
                scaleX = skala
                scaleY = skala
            }
            .shadow(
                elevation = 16.dp,
                shape = CircleShape,
                ambientColor = LuxColors.Gold,
                spotColor = LuxColors.Gold
            )
            .clip(CircleShape)
            .background(GoldGradient)
            .clickable(
                interactionSource = interaksi,
                indication = LocalIndication.current, // ripple bawaan Material
                onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onClick()
                }
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.Add,
            contentDescription = "Tambah transaksi",
            tint = LuxColors.Background,
            modifier = Modifier
                .size(30.dp)
                .rotate(rotasi)
        )
    }
}

// ============================================================
// 5. CHIP FILTER
// Perpindahan warna aktif/nonaktif dianimasikan, bukan langsung ganti.
// ============================================================
@Composable
fun ChipFilter(
    label: String,
    aktif: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val warnaLatar by animateColorAsState(
        targetValue = if (aktif) LuxColors.Gold else LuxColors.SurfaceHigh,
        animationSpec = tween(250),
        label = "chipLatar"
    )
    val warnaTeks by animateColorAsState(
        targetValue = if (aktif) LuxColors.Background else LuxColors.TextSecondary,
        animationSpec = tween(250),
        label = "chipTeks"
    )
    val warnaTepi by animateColorAsState(
        targetValue = if (aktif) Color.Transparent else Color.White.copy(alpha = 0.10f),
        animationSpec = tween(250),
        label = "chipTepi"
    )

    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(warnaLatar)
            .border(1.dp, warnaTepi, CircleShape)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = warnaTeks,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1
        )
    }
}
