package com.example.luxfinance

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

/** State layar keuangan. Data transaksi disimpan lokal agar tetap ada setelah aplikasi ditutup. */
data class KeuanganUiState(
    val ringkasan: RingkasanKeuangan = RingkasanKeuangan(0L, 0L),
    val daftar: List<Transaksi> = emptyList(),
    val filterTipe: TipeTransaksi? = null,
    val filterKategori: String? = null,
    val kategoriTersedia: List<String> = emptyList()
)

class KeuanganViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = application.getSharedPreferences("lux_finance", Context.MODE_PRIVATE)
    private val semuaTransaksi = MutableStateFlow(loadTransactions())
    private val filterTipe = MutableStateFlow<TipeTransaksi?>(null)
    private val filterKategori = MutableStateFlow<String?>(null)

    val uiState: StateFlow<KeuanganUiState> =
        combine(semuaTransaksi, filterTipe, filterKategori) { semua, tipe, kategori ->
            KeuanganUiState(
                ringkasan = semua.hitungRingkasan(),
                daftar = semua.filterBy(kategori = kategori, tipe = tipe).urutkanTerbaru(),
                filterTipe = tipe,
                filterKategori = kategori,
                kategoriTersedia = semua.filterBy(tipe = tipe).map { it.kategori }.distinct().sorted()
            )
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), KeuanganUiState())

    fun tambah(transaksi: Transaksi) {
        semuaTransaksi.update { listOf(transaksi) + it }
        saveTransactions()
    }

    fun hapus(id: String) {
        semuaTransaksi.update { daftar -> daftar.filterNot { it.id == id } }
        saveTransactions()
    }

    fun setFilterTipe(tipe: TipeTransaksi?) {
        filterTipe.value = tipe
        filterKategori.value = null
    }

    fun setFilterKategori(kategori: String?) { filterKategori.value = kategori }

    private fun saveTransactions() {
        val json = JSONArray()
        semuaTransaksi.value.forEach { t ->
            json.put(JSONObject().apply {
                put("id", t.id); put("judul", t.judul); put("nominal", t.nominal)
                put("tipe", t.tipe.name); put("kategori", t.kategori); put("tanggal", t.tanggal.toString())
            })
        }
        prefs.edit().putString("transactions", json.toString()).apply()
    }

    private fun loadTransactions(): List<Transaksi> {
        val saved = prefs.getString("transactions", null)
        if (saved != null) {
            return runCatching {
                val json = JSONArray(saved)
                (0 until json.length()).map { i ->
                    val o = json.getJSONObject(i)
                    Transaksi(
                        id = o.getString("id"), judul = o.getString("judul"),
                        nominal = o.getLong("nominal"), tipe = TipeTransaksi.valueOf(o.getString("tipe")),
                        kategori = o.getString("kategori"), tanggal = LocalDate.parse(o.getString("tanggal"))
                    )
                }
            }.getOrElse { dataContoh() }
        }
        return dataContoh().also {
            // Seed hanya sekali pada instalasi pertama.
            val json = JSONArray()
            it.forEach { t -> json.put(JSONObject().apply {
                put("id", t.id); put("judul", t.judul); put("nominal", t.nominal)
                put("tipe", t.tipe.name); put("kategori", t.kategori); put("tanggal", t.tanggal.toString())
            }) }
            prefs.edit().putString("transactions", json.toString()).apply()
        }
    }
}

private fun dataContoh(): List<Transaksi> {
    val hariIni = LocalDate.now()
    return listOf(
        Transaksi(judul = "Gaji Bulanan", nominal = 12_500_000, tipe = TipeTransaksi.PEMASUKAN, kategori = "Gaji", tanggal = hariIni.minusDays(1)),
        Transaksi(judul = "Makan Malam", nominal = 185_000, tipe = TipeTransaksi.PENGELUARAN, kategori = "Makan", tanggal = hariIni),
        Transaksi(judul = "Bayar Listrik", nominal = 450_000, tipe = TipeTransaksi.PENGELUARAN, kategori = "Tagihan", tanggal = hariIni.minusDays(2)),
        Transaksi(judul = "Bonus Proyek", nominal = 2_000_000, tipe = TipeTransaksi.PEMASUKAN, kategori = "Bonus", tanggal = hariIni.minusDays(3)),
        Transaksi(judul = "Ojek Online", nominal = 42_000, tipe = TipeTransaksi.PENGELUARAN, kategori = "Transport", tanggal = hariIni.minusDays(3)),
        Transaksi(judul = "Belanja Bulanan", nominal = 1_350_000, tipe = TipeTransaksi.PENGELUARAN, kategori = "Belanja", tanggal = hariIni.minusDays(4)),
        Transaksi(judul = "Nonton Bioskop", nominal = 120_000, tipe = TipeTransaksi.PENGELUARAN, kategori = "Hiburan", tanggal = hariIni.minusDays(5)),
        Transaksi(judul = "Dividen Saham", nominal = 650_000, tipe = TipeTransaksi.PEMASUKAN, kategori = "Investasi", tanggal = hariIni.minusDays(6)),
        Transaksi(judul = "Kopi Pagi", nominal = 38_000, tipe = TipeTransaksi.PENGELUARAN, kategori = "Makan", tanggal = hariIni.minusDays(6)),
        Transaksi(judul = "Internet Rumah", nominal = 375_000, tipe = TipeTransaksi.PENGELUARAN, kategori = "Tagihan", tanggal = hariIni.minusDays(7))
    )
}
