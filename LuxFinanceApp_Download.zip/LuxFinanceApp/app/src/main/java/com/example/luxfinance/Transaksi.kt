package com.example.luxfinance

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID
import kotlin.math.abs

// ============================================================
// 1. MODEL DATA
// ============================================================

/** Jenis transaksi. `label` dipakai langsung di UI. */
enum class TipeTransaksi(val label: String) {
    PEMASUKAN("Pemasukan"),
    PENGELUARAN("Pengeluaran")
}

/**
 * Satu catatan keuangan.
 * - nominal disimpan sebagai Long (rupiah bulat) supaya bebas error pembulatan Double.
 * - LocalDate butuh minSdk 26 (atau aktifkan core library desugaring).
 */
data class Transaksi(
    val id: String = UUID.randomUUID().toString(),
    val judul: String,
    val nominal: Long,
    val tipe: TipeTransaksi,
    val kategori: String,
    val tanggal: LocalDate = LocalDate.now()
)

/** Daftar kategori bawaan untuk tiap tipe (bisa diganti dengan data dari database). */
object Kategori {
    val pemasukan = listOf("Gaji", "Bonus", "Investasi", "Lainnya")
    val pengeluaran = listOf("Makan", "Transport", "Belanja", "Tagihan", "Hiburan", "Lainnya")

    fun untuk(tipe: TipeTransaksi): List<String> =
        if (tipe == TipeTransaksi.PEMASUKAN) pemasukan else pengeluaran
}

// ============================================================
// 2. LOGIKA PERHITUNGAN
// ============================================================

/** Hasil rekap. `sisaSaldo` dihitung otomatis dari dua total di atas. */
data class RingkasanKeuangan(
    val totalPemasukan: Long,
    val totalPengeluaran: Long
) {
    val sisaSaldo: Long get() = totalPemasukan - totalPengeluaran
}

/** Menghitung total pemasukan, total pengeluaran, dan sisa saldo dari seluruh daftar. */
fun List<Transaksi>.hitungRingkasan(): RingkasanKeuangan {
    val pemasukan = filter { it.tipe == TipeTransaksi.PEMASUKAN }.sumOf { it.nominal }
    val pengeluaran = filter { it.tipe == TipeTransaksi.PENGELUARAN }.sumOf { it.nominal }
    return RingkasanKeuangan(totalPemasukan = pemasukan, totalPengeluaran = pengeluaran)
}

// ============================================================
// 3. FILTER & URUTAN
// ============================================================

/**
 * Filter berdasarkan kategori dan/atau tipe.
 * Parameter bernilai null berarti "tidak difilter" (tampilkan semua).
 * Contoh: transaksi.filterBy(tipe = TipeTransaksi.PENGELUARAN, kategori = "Makan")
 */
fun List<Transaksi>.filterBy(
    kategori: String? = null,
    tipe: TipeTransaksi? = null
): List<Transaksi> = filter { t ->
    (tipe == null || t.tipe == tipe) &&
        (kategori == null || t.kategori.equals(kategori, ignoreCase = true))
}

/** Tanggal terbaru di atas. Sort-nya stabil, jadi urutan input dipertahankan untuk tanggal yang sama. */
fun List<Transaksi>.urutkanTerbaru(): List<Transaksi> = sortedByDescending { it.tanggal }

// ============================================================
// 4. FORMAT TAMPILAN
// ============================================================

private val localeId: Locale = Locale.forLanguageTag("id-ID")
private val formatterTanggal: DateTimeFormatter = DateTimeFormatter.ofPattern("d MMM yyyy", localeId)

/** 1500000 -> "Rp 1.500.000" (titik sebagai pemisah ribuan, negatif -> "-Rp ..."). */
fun formatRupiah(nilai: Long): String {
    val tanda = if (nilai < 0) "-" else ""
    return "${tanda}Rp ${String.format(localeId, "%,d", abs(nilai))}"
}

/** 2026-10-24 -> "24 Okt 2026" */
fun LocalDate.formatTanggal(): String = format(formatterTanggal)
