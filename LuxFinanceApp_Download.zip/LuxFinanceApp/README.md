# Lux Finance — Dark Luxury

Aplikasi pencatat keuangan Android dengan Kotlin + Jetpack Compose.

## Fitur
- Dashboard saldo, total pemasukan, dan total pengeluaran.
- Riwayat transaksi dengan kategori dan filter.
- Tambah pemasukan/pengeluaran dan validasi nominal.
- Data transaksi tersimpan secara lokal di SharedPreferences sehingga tetap ada setelah aplikasi ditutup.
- Hapus transaksi dengan menekan lama item riwayat lalu konfirmasi.
- Tema dark luxury hitam-emas, kartu berkilau, count-up rupiah, animasi masuk, tombol tambah dengan haptic.
- Contoh transaksi awal dimasukkan hanya pada peluncuran pertama.

## Build APK di Android Studio
1. Instal Android Studio versi terbaru dan Android SDK Platform 35.
2. Ekstrak folder `LuxFinanceApp`.
3. Android Studio → **Open** → pilih folder `LuxFinanceApp`.
4. Tunggu Gradle Sync selesai.
5. Pilih **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan
- Minimum Android: 8.0 (API 26).
- Data disimpan lokal di perangkat, tidak dikirim ke server.
- Ini bukan aplikasi bank dan tidak terhubung ke rekening atau investasi.
- Package/application ID: `com.example.luxfinance` (bisa diubah sebelum rilis).
